const  bill_amount=document.querySelector('#amount');
const  num_of_people=document.getElementById("numberOfPeople");
console.log(bill_amount);
